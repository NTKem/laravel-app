<?php $__env->startSection('class','home'); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="title">select your profile</h2>
    <div class="menu-bar">
        <?php
        foreach ($profile as $item):
        ?>
        <div class="items">
            <a class="link-bar" href="<?php echo e(route($item->url,['id' => $item->id])); ?>">
                <img src="<?php echo e(asset('images/profile/'. $item->image.'')); ?>">
                <p><?php echo e($item->name); ?></p>
            </a>
        </div>
        <?php
        endforeach
        ;?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopify-app-laravel\resources\views/pages/index.blade.php ENDPATH**/ ?>