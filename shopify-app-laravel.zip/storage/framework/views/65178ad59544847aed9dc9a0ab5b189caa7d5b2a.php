<style>
 
    body,*{
       font-size:<?= $settings['font_size'] ?>px;
    }
</style><?php /**PATH C:\xampp\htdocs\shopify-app-laravel\resources\views/css/settings.blade.php ENDPATH**/ ?>