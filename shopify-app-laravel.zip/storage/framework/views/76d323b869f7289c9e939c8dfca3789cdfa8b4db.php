<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?php echo e(asset('')); ?>">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="shortcut icon" href="/favicon.ico">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
    
    <link href="<?php echo e(mix('/css/app.css')); ?>" rel="stylesheet">
    
    <script>
        window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
            ]); ?>;
    </script>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
<div id="app">
    <main class="py-4">
        <div class="main-bottom">
            <div class="tool-bar">
                <div class="left"><i class="fa fa-sync"></i></div>
                <div class="center">accessibility</div>
                <div class="right"><i class="fa fa-times"></i></div>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
</div>


<script src="<?php echo e(mix('/js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('footer_scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\shopify-app-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>