<?php $__env->startSection('content'); ?>
    <h2 class="title">select your profile</h2>
    <div class="menu-bar">
        <div class="items">
            <a href="">
                <img src="images/icon_1.png">
                <p>Elderly</p>
            </a>
        </div>
        <div class="items">
            <a>
                <img src="images/icon_2.png">
                <p>Situational</p>
            </a>
        </div>
        <div class="items">
            <a>
                <img src="images/icon_3.png">
                <p>Dislexia</p>
            </a>
        </div>
        <div class="items">
            <a>
                <img src="images/icon_4.png">
                <p>Mobility Impaired</p>
            </a>
        </div>
        <div class="items">
            <a>
                <img src="images/icon_5.png">
                <p>Visually Impaired</p>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopify-app-laravel\resources\views/index.blade.php ENDPATH**/ ?>