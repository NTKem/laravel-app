<?php $__env->startSection('class','ederly'); ?>
<?php $__env->startSection('content'); ?>

    <div class="tab-bar">
        <?php foreach ($site_menu as  $key => $menu_items):?>
        <div class="items <?php if($key == 0):?>items-active<?php endif; ?>" data-href="#tabs-<?php echo e($key); ?>"><?php echo e($menu_items->name); ?></div>
        <?php endforeach;?>
    </div>
    <div class="main-section">
            <?php foreach ($site_menu as  $key => $menu_items):?>
            <?php if($menu_items->name == 'Readable Text'):?>
            <div class="menu-bar active-bar hidden readable-text" id="tabs-<?php echo e($key); ?>">
                <div class="items">
                    <img src="<?php echo e(asset('images/line-height.png')); ?>">
                    <p>Line<br> Height</p>
                    <div class="main-action">
                        <i class="fa fa-plus"></i>
                        <input class="custom-input" type="hidden" name="line_height" value="16" min="1" max="100"/>
                        <i class="fa fa-minus"></i>
                    </div>
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/Font-size.png')); ?>">
                    <p>Font<br> Size</p>
                    <div class="main-action">
                        <i class="fa fa-plus"></i>
                        <input class="custom-input" type="hidden" name="font_size" value="16" min="1" max="100"/>
                        <i class="fa fa-minus"></i>
                    </div>
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/Font-spacing.png')); ?>">
                    <p>Font<br> Spacing</p>
                    <div class="main-action">
                        <i class="fa fa-plus"></i>
                        <input class="custom-input" type="hidden" name="font_spacing" value="0"  min="0" max="100" />
                        <i class="fa fa-minus"></i>
                    </div>
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Change Font'): ?>
            <div class="menu-bar hidden change-font" id="tabs-<?php echo e($key); ?>">
                <div class="font-list">
                    <?php foreach ($site_font as $font_items):?>
                    <div class="list-items">
                        <input type="radio" data-action="<?php echo e($font_items->font_face); ?>" name="font" value="<?php echo e($font_items->id); ?>"/>
                        <?php echo e($font_items->name); ?>

                    </div>
                    <?php endforeach;?>
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Color More'): ?>
            <div class="menu-bar hidden color-more" id="tabs-<?php echo e($key); ?>">
                <div class="items">
                    <img src="<?php echo e(asset('images/color/Grayscale.png')); ?>">
                    <p>Grayscale</p>
                    <input type="checkbox" name="grayscale" value="true"/>
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/color/invert-colors.png')); ?>">
                    <p>Invert Colors</p>
                    <input type="checkbox" name="invert_colors" value="true" />
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/color/sepia.png')); ?>">
                    <p>Sepia</p>
                    <input type="checkbox" name="sepia" value="true"/>
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Highlight'): ?>
            <div class="menu-bar hidden highlight" id="tabs-<?php echo e($key); ?>">
                <div class="items" >
                    <img src="<?php echo e(asset('images/highlight/title.png')); ?>">
                    <p>Highlight Title</p>
                    <input type="checkbox" name="highlight_title" value="true"/>
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/highlight/links.png')); ?>">
                    <p>Highlight Link</p>
                    <input type="checkbox" name="highlight_links" value="true"/>
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/highlight/focus.png')); ?>">
                    <p>Highlight Focus</p>
                    <input type="checkbox" name="highlight_focus" value="true" />
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Ship Link'): ?>
            <div class="menu-bar hidden skip-link" id="tabs-<?php echo e($key); ?>">
                <div class="items">
                    <img src="<?php echo e(asset('images/skip/title.png')); ?>">
                    <p>Skip Title</p>
                    <input type="checkbox" name="skip_title" value="true" />
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/skip/links.png')); ?>">
                    <p>Skip Link</p>
                    <input type="checkbox" name="skip_links" value="true" />
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/skip/focus.png')); ?>">
                    <p>Skip Focus</p>
                    <input type="checkbox" name="skip_focus" value="true" />
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Screen Settings'): ?>
            <div class="menu-bar hidden screen_settings" id="tabs-<?php echo e($key); ?>">
                <div class="items">
                    <img src="<?php echo e(asset('images/screen-settings/mask.png')); ?>">
                    <p>Screen Mask</p>
                    <input type="checkbox" name="screen_settings" value="true"/>
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/screen-settings/ruler.png')); ?>">
                    <p>Screen Ruler</p>
                    <input type="checkbox" name="screen_ruler" value="true"/>
                </div>
                <div class="items radio-items">
                    <img src="<?php echo e(asset('images/screen-settings/cursor.png')); ?>">
                    <p>Blank Cursor</p>
                    <input type="radio" name="screen_cursor" value="blank"/>
                </div>
                <div class="items radio-items">
                    <img src="<?php echo e(asset('images/screen-settings/white-cursor.png')); ?>">
                    <p>White Cursor</p>
                    <input type="radio" name="screen_cursor" value="white" />
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Zoom'): ?>
            <div class="menu-bar hidden zoom" id="tabs-<?php echo e($key); ?>">
                <div class="items zoom-increase">
                    <img src="<?php echo e(asset('images/zoom/increase.png')); ?>">
                    <p>Increase</p>
                </div>
                <div class="items zoom-decrease">
                    <img src="<?php echo e(asset('images/zoom/decrease.png')); ?>">
                    <p>Decrease</p>
                </div>
                <input type="hidden" class="zoom-input" value="0"name="zoom" min="-3" max="3">
            </div>
            <?php elseif ($menu_items->name == 'Contrast'): ?>
            <div class="menu-bar hidden contrast" id="tabs-<?php echo e($key); ?>">
                <div class="contrast-content">
                    <?php foreach ($site_contrast as  $key => $color_items):?>
                    <?php if($color_items->color == 'null'):?>
                    <div class="contrast-items" data-index="<?= $key?>" data-id="<?php echo e($color_items->id); ?>">
                        <i class="far fa-times-circle"></i>
                        <input type="radio" name="contrast" value="default" />
                    </div>
                    <?php else: ?>
                    <div class="contrast-items" data-index="<?= $key?>" style="background: <?php echo e($color_items->background); ?>;color:<?php echo e($color_items->color); ?>" data-id="<?php echo e($color_items->id); ?>">
                        A
                        <input type="radio" name="contrast" value="<?php echo e($color_items->id); ?>" />
                    </div>
                    <?php endif; ?>

                    <?php endforeach;?>
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Tool Tip'): ?>
            <div class="menu-bar hidden tooltips" id="tabs-<?php echo e($key); ?>">
                <div class="items">
                    <img src="<?php echo e(asset('images/tooltips/permanent.png')); ?>">
                    <p>Permanent</p>
                    <input type="checkbox" name="tooltip_permanent" value="true" />
                </div>
                <div class="items">
                    <img src="<?php echo e(asset('images/tooltips/on-mouse-over.png')); ?>">
                    <p>On Mouse Over</p>
                    <input type="checkbox" name="tooltip_mouseover" value="true" />
                </div>
            </div>
            <?php elseif ($menu_items->name == 'Other'): ?>
            <div class="menu-bar hidden others" id="tabs-<?php echo e($key); ?>">
                <div class="items">
                    <img src="<?php echo e(asset('images/others/plain-text-mode.png')); ?>">
                    <p>Plain Text Mode</p>
                </div>
                <div class="items reset">
                    <img src="<?php echo e(asset('images/others/reset.png')); ?>">
                    <p>Reset</p>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach;?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopify-app-laravel\resources\views/pages/profile/elderly.blade.php ENDPATH**/ ?>